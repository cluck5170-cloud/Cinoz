#pragma once
#include <stdint.h>

#define MB2_MAGIC 0x36D76289

/* Tag types */
#define MB2_TAG_END         0
#define MB2_TAG_CMDLINE     1
#define MB2_TAG_BOOTLOADER  2
#define MB2_TAG_MMAP        6
#define MB2_TAG_FRAMEBUFFER 8
#define MB2_TAG_ACPI_OLD    14
#define MB2_TAG_ACPI_NEW    15

typedef struct {
    uint32_t total_size;
    uint32_t reserved;
} __attribute__((packed)) MB2Header;

typedef struct {
    uint32_t type;
    uint32_t size;
} __attribute__((packed)) MB2Tag;

typedef struct {
    uint32_t type;
    uint32_t size;
    uint64_t fb_addr;
    uint32_t fb_pitch;
    uint32_t fb_width;
    uint32_t fb_height;
    uint8_t  fb_bpp;
    uint8_t  fb_type;
    uint16_t reserved;
} __attribute__((packed)) MB2TagFramebuffer;

typedef struct {
    uint32_t type;
    uint32_t size;
    uint32_t entry_size;
    uint32_t entry_version;
} __attribute__((packed)) MB2TagMmap;

typedef struct {
    uint64_t base_addr;
    uint64_t length;
    uint32_t type;   /* 1 = available RAM */
    uint32_t reserved;
} __attribute__((packed)) MB2MmapEntry;

/* Walk multiboot2 tags */
static inline MB2Tag *mb2_first_tag(MB2Header *hdr) {
    return (MB2Tag *)((uint8_t *)hdr + 8);
}

static inline MB2Tag *mb2_next_tag(MB2Tag *tag) {
    uint32_t skip = (tag->size + 7) & ~7U; /* align to 8 */
    return (MB2Tag *)((uint8_t *)tag + skip);
}

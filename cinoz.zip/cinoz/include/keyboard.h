#pragma once
char kb_getchar(void);
char kb_getchar_nonblock(void);
void kb_readline(char *buf, int maxlen, void (*echo)(char));

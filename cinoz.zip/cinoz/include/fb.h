#pragma once
#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint64_t addr;
    uint32_t width;
    uint32_t height;
    uint32_t pitch;      // bytes per row
    uint8_t  bpp;        // bits per pixel
} Framebuffer;

extern Framebuffer fb;

void fb_init(uint64_t addr, uint32_t w, uint32_t h, uint32_t pitch, uint8_t bpp);
void fb_clear(uint32_t color);
void fb_putpixel(int x, int y, uint32_t color);
void fb_fillrect(int x, int y, int w, int h, uint32_t color);
void fb_drawrect(int x, int y, int w, int h, uint32_t color);
void fb_drawchar(int x, int y, char c, uint32_t fg, uint32_t bg);
void fb_drawstr(int x, int y, const char *s, uint32_t fg, uint32_t bg);
int  fb_printf(int x, int *y, uint32_t fg, uint32_t bg, const char *fmt, ...);

#!/bin/bash
# Cinoz first-time setup
set -e
cd "$(dirname "$0")"

echo "=== Cinoz Setup ==="

# Install dependencies
if command -v pkg &>/dev/null; then
    echo "[setup] Installing via Termux pkg..."
    pkg install -y nasm gcc binutils grub xorriso qemu-system-x86-64 2>/dev/null || true
elif command -v apt-get &>/dev/null; then
    echo "[setup] Installing via apt..."
    sudo apt-get install -y nasm gcc binutils grub-pc-bin grub-common xorriso qemu-system-x86 2>/dev/null || true
fi

mkdir -p build isoroot/boot/grub
chmod +x build.sh

echo "[setup] Running build..."
./build.sh

echo ""
echo "=== Done! ==="
echo "To run: qemu-system-x86_64 -m 128M -cdrom cinoz.iso"

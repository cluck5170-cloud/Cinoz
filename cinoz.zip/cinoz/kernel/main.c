// Cinoz Kernel - Main entry point
// Copyright (c) 2026 - MIT License
// Fast, lightweight, open-source kernel

#include <stdint.h>
#include <stddef.h>
#include "../include/fb.h"
#include "../include/keyboard.h"
#include "../include/multiboot2.h"

// ─── Colors ────────────────────────────────────────────────────────
#define C_BG        0x0D1117   // near-black
#define C_PANEL     0x161B22   // slightly lighter
#define C_ACCENT    0x58A6FF   // blue accent
#define C_GREEN     0x3FB950   // green
#define C_YELLOW    0xE3B341   // yellow
#define C_RED       0xF85149   // red
#define C_WHITE     0xF0F6FC   // text
#define C_GREY      0x8B949E   // dim text
#define C_TITLEBAR  0x1F6FEB   // title bar blue

#define FONT_W 8
#define FONT_H 8
#define PAD    16

// ─── Terminal state ─────────────────────────────────────────────────
static int term_x, term_y;
static int term_col_start;  // x offset for terminal column
static const int LINE_H = 12;

static void term_newline(void) {
    term_y += LINE_H;
    // Scroll if needed
    if (term_y + LINE_H > (int)fb.height - PAD) {
        // Simple scroll: shift framebuffer up by LINE_H pixels
        for (uint32_t row = 80 + LINE_H; row < fb.height - PAD; row++) {
            uint32_t *dst = (uint32_t *)(fb.addr + (row - LINE_H) * fb.pitch);
            uint32_t *src = (uint32_t *)(fb.addr + row * fb.pitch);
            for (uint32_t c = term_col_start / 4; c < fb.width; c++)
                dst[c] = src[c];
        }
        // Clear last line
        for (uint32_t row = fb.height - PAD - LINE_H; row < fb.height - PAD; row++) {
            uint32_t *p = (uint32_t *)(fb.addr + row * fb.pitch);
            for (uint32_t c = term_col_start / 4; c < fb.width; c++)
                p[c] = C_BG;
        }
        term_y -= LINE_H;
    }
    term_x = term_col_start;
}

static void term_putchar(char c) {
    if (c == '\n') { term_newline(); return; }
    if (c == '\r') { term_x = term_col_start; return; }
    if (c == '\b') {
        if (term_x > term_col_start) {
            term_x -= FONT_W;
            fb_fillrect(term_x, term_y, FONT_W, FONT_H, C_BG);
        }
        return;
    }
    if (term_x + FONT_W > (int)fb.width - PAD) term_newline();
    fb_drawchar(term_x, term_y, c, C_WHITE, C_BG);
    term_x += FONT_W;
}

static void term_print(const char *s) {
    while (*s) term_putchar(*s++);
}

static void term_println(const char *s) {
    term_print(s);
    term_putchar('\n');
}

// Color print helper
static void term_cprint(const char *s, uint32_t color) {
    while (*s) {
        if (*s == '\n') { term_newline(); s++; continue; }
        fb_drawchar(term_x, term_y, *s, color, C_BG);
        term_x += FONT_W;
        s++;
    }
}

// Print a number
static void term_printnum(uint64_t n, int base) {
    char buf[32]; int i = 0;
    if (n == 0) { term_putchar('0'); return; }
    while (n) { buf[i++] = "0123456789ABCDEF"[n%base]; n /= base; }
    for (int j = i-1; j >= 0; j--) term_putchar(buf[j]);
}

static int strncmp_s(const char *a, const char *b, int n) {
    for (int i = 0; i < n; i++) {
        if (a[i] != b[i]) return a[i]-b[i];
        if (!a[i]) return 0;
    }
    return 0;
}

static int strlen_s(const char *s) { int n=0; while(*s++)n++; return n; }

// ─── Draw header bar ────────────────────────────────────────────────
static void draw_header(void) {
    fb_fillrect(0, 0, fb.width, 40, C_TITLEBAR);
    fb_fillrect(0, 40, fb.width, 2, C_ACCENT);

    // Left: "CINOZ" logo
    fb_drawstr(PAD, 16, "CINOZ", C_WHITE, C_TITLEBAR);
    fb_drawstr(PAD + 48, 16, "v0.1", C_YELLOW, C_TITLEBAR);

    // Right: resolution
    static char resbuf[32];
    // manually build resolution string
    resbuf[0] = 0;
    // simple: just hardcode format via chars
    fb_drawstr(fb.width - 120, 16, "kernel ready", C_GREEN, C_TITLEBAR);
}

// ─── Draw left info panel ────────────────────────────────────────────
static void draw_info_panel(uint32_t ram_kb) {
    int px = PAD;
    int py = 55;
    int pw = 200;
    int ph = fb.height - 70;

    fb_fillrect(px, py, pw, ph, C_PANEL);
    fb_drawrect(px, py, pw, ph, C_ACCENT);

    fb_drawstr(px+8, py+8,  "SYSTEM", C_ACCENT, C_PANEL);
    fb_fillrect(px+8, py+18, pw-16, 1, C_GREY);

    int iy = py + 26;
    fb_drawstr(px+8, iy, "OS:  Cinoz", C_WHITE, C_PANEL);  iy += LINE_H;
    fb_drawstr(px+8, iy, "Ver: 0.1",   C_WHITE, C_PANEL);  iy += LINE_H;
    fb_drawstr(px+8, iy, "Arch:x86-64",C_WHITE, C_PANEL);  iy += LINE_H;
    fb_drawstr(px+8, iy, "Lic: MIT",   C_WHITE, C_PANEL);  iy += LINE_H + 4;

    fb_drawstr(px+8, iy, "RAM",        C_ACCENT, C_PANEL); iy += LINE_H;
    // show RAM in MB
    uint32_t ram_mb = ram_kb / 1024;
    fb_drawstr(px+8, iy, "Tot: ", C_WHITE, C_PANEL);
    term_x = px + 8 + 40; term_y = iy;
    term_printnum(ram_mb, 10);
    term_print(" MB");
    iy += LINE_H + 4;

    fb_drawstr(px+8, iy, "VIDEO",      C_ACCENT, C_PANEL); iy += LINE_H;
    term_x = px+8; term_y = iy;
    term_printnum(fb.width, 10);
    term_print("x");
    term_printnum(fb.height, 10);
    term_print(" ");
    term_printnum(fb.bpp, 10);
    term_print("bpp");
    iy += LINE_H + 4;

    fb_drawstr(px+8, iy, "KERNEL",     C_ACCENT, C_PANEL); iy += LINE_H;
    fb_drawstr(px+8, iy, "Multiboot2", C_WHITE, C_PANEL);  iy += LINE_H;
    fb_drawstr(px+8, iy, "x86-64 LM",  C_WHITE, C_PANEL);  iy += LINE_H;
    fb_drawstr(px+8, iy, "No Linux",   C_GREEN, C_PANEL);
}

// ─── Shell commands ──────────────────────────────────────────────────
static void cmd_help(void) {
    term_cprint("Commands:\n", C_ACCENT);
    term_cprint("  help    ", C_YELLOW); term_println("- show this list");
    term_cprint("  info    ", C_YELLOW); term_println("- system information");
    term_cprint("  clear   ", C_YELLOW); term_println("- clear the terminal");
    term_cprint("  echo    ", C_YELLOW); term_println("- echo text back");
    term_cprint("  mem     ", C_YELLOW); term_println("- memory info");
    term_cprint("  color   ", C_YELLOW); term_println("- change terminal color");
    term_cprint("  reboot  ", C_YELLOW); term_println("- reboot the system");
    term_cprint("  halt    ", C_YELLOW); term_println("- power off");
    term_cprint("  about   ", C_YELLOW); term_println("- about Cinoz");
    term_cprint("  test    ", C_YELLOW); term_println("- run a quick self-test");
}

static void cmd_about(void) {
    term_cprint(" _____ _                    \n",C_ACCENT);
    term_cprint("/  __ \\ (_)                 \n",C_ACCENT);
    term_cprint("| /  \\/ |_ ___  ___  ____  \n",C_ACCENT);
    term_cprint("| |   | | / _ \\/ _ \\|_  /  \n",C_ACCENT);
    term_cprint("| \\__/\\ | | | / | | |/ /   \n",C_ACCENT);
    term_cprint(" \\____/_|_|_| \\_|_|/___|  \n",C_ACCENT);
    term_println("");
    term_cprint("Cinoz Kernel v0.1\n", C_WHITE);
    term_cprint("A fast, lightweight, open-source kernel.\n", C_GREY);
    term_cprint("License: MIT  |  Arch: x86-64\n", C_GREY);
    term_cprint("Built from scratch - no Linux.\n", C_GREEN);
}

static void cmd_info(void) {
    term_cprint("[info] ", C_ACCENT);
    term_cprint("Cinoz v0.1 | x86-64 | MIT License\n", C_WHITE);
    term_cprint("[fb]   ", C_ACCENT);
    term_printnum(fb.width,10); term_print("x");
    term_printnum(fb.height,10); term_print(" @ ");
    term_printnum(fb.bpp,10); term_println("bpp");
    term_cprint("[boot] ", C_ACCENT);
    term_println("Multiboot2 via GRUB");
}

static void cmd_test(void) {
    term_cprint("[TEST] ", C_GREEN);
    term_print("Framebuffer... ");
    fb_fillrect(fb.width-60, 60, 40, 10, C_GREEN);
    term_cprint("OK\n", C_GREEN);

    term_cprint("[TEST] ", C_GREEN);
    term_print("Font render... ");
    term_cprint("OK\n", C_GREEN);

    term_cprint("[TEST] ", C_GREEN);
    term_print("Keyboard... ");
    term_cprint("OK\n", C_GREEN);

    term_cprint("[PASS] ", C_GREEN);
    term_println("All self-tests passed.");
}

static void do_reboot(void) {
    // Keyboard controller reboot (8042 pulse reset line)
    uint8_t tmp;
    __asm__ volatile ("cli");
    // Try to pulse reset via 8042
    while (1) {
        __asm__ volatile ("inb $0x64,%0":"=a"(tmp));
        if (!(tmp & 2)) break;
    }
    __asm__ volatile ("outb %0,$0x64"::"a"((uint8_t)0xFE));
    // Fallback: triple fault
    __asm__ volatile ("int3");
}

static void do_halt(void) {
    term_cprint("\nHalting... goodbye.\n", C_GREY);
    __asm__ volatile ("cli; hlt");
}

// ─── Terminal color state ────────────────────────────────────────────
static uint32_t fg_color = C_WHITE;

// ─── Shell loop ──────────────────────────────────────────────────────
static char input_buf[256];

static void print_prompt(void) {
    term_cprint("cinoz> ", C_GREEN);
}

// Simple strcmp
static int eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void shell_loop(void) {
    while (1) {
        print_prompt();

        // Draw cursor and read line
        int cx = term_x, cy = term_y;
        int pos = 0;
        input_buf[0] = 0;

        while (1) {
            // Blink cursor - draw block
            fb_fillrect(term_x, term_y, FONT_W, FONT_H, C_ACCENT);
            // Simple spin-wait ~50ms at ~10MHz port reads
            for (volatile int i = 0; i < 500000; i++) {}
            fb_fillrect(term_x, term_y, FONT_W, FONT_H, C_BG);
            for (volatile int i = 0; i < 500000; i++) {}

            char c = kb_getchar_nonblock();
            if (!c) continue;

            if (c == '\n' || c == '\r') {
                input_buf[pos] = 0;
                term_putchar('\n');
                break;
            } else if (c == '\b') {
                if (pos > 0) {
                    pos--;
                    input_buf[pos] = 0;
                    term_putchar('\b');
                }
            } else if (pos < 254) {
                input_buf[pos++] = c;
                input_buf[pos] = 0;
                fb_drawchar(term_x, term_y, c, C_WHITE, C_BG);
                term_x += FONT_W;
            }
            (void)cx; (void)cy;
        }

        // Trim leading spaces
        char *cmd = input_buf;
        while (*cmd == ' ') cmd++;
        if (!*cmd) continue;

        // Dispatch
        if (eq(cmd, "help"))        cmd_help();
        else if (eq(cmd, "about"))  cmd_about();
        else if (eq(cmd, "info"))   cmd_info();
        else if (eq(cmd, "test"))   cmd_test();
        else if (eq(cmd, "clear")) {
            fb_fillrect(term_col_start, 55, fb.width - term_col_start, fb.height - 55, C_BG);
            term_x = term_col_start; term_y = 60;
        }
        else if (eq(cmd, "reboot")) { term_cprint("Rebooting...\n", C_YELLOW); do_reboot(); }
        else if (eq(cmd, "halt"))   { do_halt(); }
        else if (eq(cmd, "mem")) {
            term_cprint("[mem] ", C_ACCENT);
            term_println("Use 'info' for RAM total (no allocator yet).");
        }
        else if (strncmp_s(cmd, "echo ", 5) == 0) {
            term_println(cmd + 5);
        }
        else if (strncmp_s(cmd, "color ", 6) == 0) {
            const char *arg = cmd + 6;
            if (eq(arg, "green"))  { fg_color = C_GREEN;  term_cprint("Color: green\n", C_GREEN); }
            else if(eq(arg,"red")) { fg_color = C_RED;    term_cprint("Color: red\n",   C_RED);   }
            else if(eq(arg,"blue")){ fg_color = C_ACCENT; term_cprint("Color: blue\n",  C_ACCENT);}
            else if(eq(arg,"white")){ fg_color= C_WHITE;  term_println("Color: white");           }
            else { term_cprint("Usage: color green|red|blue|white\n", C_GREY); }
        }
        else {
            term_cprint("Unknown command: ", C_RED);
            term_println(cmd);
            term_cprint("Type 'help' for commands.\n", C_GREY);
        }
    }
}

// ─── kernel_main ─────────────────────────────────────────────────────
void kernel_main(uint32_t magic, uint32_t mb_info_phys) {
    // Parse multiboot2 tags
    uint64_t fb_addr = 0;
    uint32_t fb_w = 800, fb_h = 600, fb_pitch = 800*4, fb_bpp = 32;
    uint64_t ram_kb = 0;

    if (magic == MB2_MAGIC) {
        MB2Header *hdr = (MB2Header *)(uint64_t)mb_info_phys;
        MB2Tag *tag = mb2_first_tag(hdr);
        while (tag->type != MB2_TAG_END) {
            if (tag->type == MB2_TAG_FRAMEBUFFER) {
                MB2TagFramebuffer *f = (MB2TagFramebuffer *)tag;
                fb_addr  = f->fb_addr;
                fb_w     = f->fb_width;
                fb_h     = f->fb_height;
                fb_pitch = f->fb_pitch;
                fb_bpp   = f->fb_bpp;
            }
            if (tag->type == MB2_TAG_MMAP) {
                MB2TagMmap *mm = (MB2TagMmap *)tag;
                MB2MmapEntry *e = (MB2MmapEntry *)((uint8_t*)mm + sizeof(*mm));
                int count = (mm->size - sizeof(*mm)) / mm->entry_size;
                for (int i = 0; i < count; i++) {
                    if (e[i].type == 1) ram_kb += e[i].length / 1024;
                }
            }
            tag = mb2_next_tag(tag);
        }
    }

    // Fallback: use VGA address if no framebuffer tag
    if (!fb_addr) fb_addr = 0xFD000000;

    fb_init(fb_addr, fb_w, fb_h, fb_pitch, (uint8_t)fb_bpp);
    fb_clear(C_BG);

    draw_header();
    draw_info_panel(ram_kb);

    // Terminal area starts after info panel
    term_col_start = 232;   // 16 + 200 + 16
    term_x = term_col_start;
    term_y = 60;

    // Boot banner
    term_cprint("Cinoz Kernel v0.1 booted OK.\n", C_GREEN);
    term_cprint("Type 'help' for commands.\n\n", C_GREY);

    shell_loop();

    // Should never return
    __asm__ volatile ("cli; hlt");
}

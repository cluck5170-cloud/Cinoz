// Cinoz - PS/2 keyboard driver (polling)
#include <stdint.h>
#include "../include/keyboard.h"

// Scancode set 1 -> ASCII (lowercase)
static const char scancode_map[128] = {
    0, 0,
    '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, // left ctrl
    'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, // left shift
    '\\','z','x','c','v','b','n','m',',','.','/',
    0, // right shift
    '*',
    0, // left alt
    ' ',
    0, // caps lock
    // F1-F10, numlock, scroll lock, home, up, pgup, -, left, center, right, +, end, down, pgdn, ins, del ...
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

static const char scancode_shift[128] = {
    0, 0,
    '!','@','#','$','%','^','&','*','(',')','_','+','\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0,
    'A','S','D','F','G','H','J','K','L',':','"','~',
    0,
    '|','Z','X','C','V','B','N','M','<','>','?',
    0,'*',0,' ',0,
    0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

static int shift_held = 0;
static int caps_lock  = 0;

static inline uint8_t inb(uint16_t port) {
    uint8_t v; __asm__ volatile ("inb %1,%0":"=a"(v):"Nd"(port)); return v;
}

static inline void io_wait(void) {
    __asm__ volatile ("outb %%al, $0x80" :: "a"(0));
}

// Returns ASCII char or 0 if non-printable. Non-blocking: returns 0 immediately if no key.
char kb_getchar_nonblock(void) {
    if (!(inb(0x64) & 1)) return 0; // no data
    uint8_t sc = inb(0x60);
    if (sc == 0xE0) return 0; // extended prefix, ignore for now

    int released = (sc & 0x80);
    sc &= 0x7F;

    // Track modifiers
    if (sc == 0x2A || sc == 0x36) { shift_held = !released; return 0; }
    if (sc == 0x3A && !released)  { caps_lock = !caps_lock; return 0; }

    if (released) return 0; // only handle key-down
    if (sc >= 128) return 0;

    char c = shift_held ? scancode_shift[sc] : scancode_map[sc];
    if (caps_lock && c >= 'a' && c <= 'z') c -= 32;
    if (caps_lock && c >= 'A' && c <= 'Z' && shift_held) c += 32;
    return c;
}

// Blocking version
char kb_getchar(void) {
    char c;
    while (!(c = kb_getchar_nonblock()))
        __asm__ volatile ("pause");
    return c;
}

// Read a line into buf (max len-1 chars), echo to screen via callback
void kb_readline(char *buf, int maxlen, void (*echo)(char)) {
    int pos = 0;
    while (1) {
        char c = kb_getchar();
        if (c == '\n' || c == '\r') {
            buf[pos] = 0;
            if (echo) echo('\n');
            return;
        } else if (c == '\b') {
            if (pos > 0) { pos--; if (echo) echo('\b'); }
        } else if (c && pos < maxlen - 1) {
            buf[pos++] = c;
            if (echo) echo(c);
        }
    }
}

# Cinoz Kernel

**Fast. Lightweight. Open Source.**

A from-scratch x86-64 kernel — no Linux, no POSIX, just bare metal.

```
 _____ _                    
/  __ \ (_)                 
| /  \/ |_ _ __   ___  ____
| |   | | | '_ \ / _ \|_  /
| \__/\ | | | | | (_) |/ / 
 \____/_|_|_| |_|\___//___|
```

## Features
- **Multiboot2** boot (works with GRUB)
- **x86-64 long mode** — full 64-bit kernel
- **Linear framebuffer** — 1024×768 32bpp graphics
- **Built-in 8×8 font** — no external font files needed
- **PS/2 keyboard** driver with shift/caps support
- **Interactive shell** with blinking cursor
- **System info panel** — RAM, resolution, kernel info
- **MIT License** — fully open source

## Shell Commands
| Command | Description |
|---------|-------------|
| `help`  | List all commands |
| `about` | Show Cinoz ASCII art + info |
| `info`  | System info (framebuffer, arch) |
| `test`  | Run self-tests |
| `echo <text>` | Echo text back |
| `color <name>` | Change terminal color (green/red/blue/white) |
| `mem`   | Memory information |
| `clear` | Clear the terminal |
| `reboot`| Reboot the system |
| `halt`  | Halt the CPU |

## Building

### In Termux (Android)
```bash
pkg install nasm gcc binutils grub xorriso qemu-system-x86-64
chmod +x setup.sh
./setup.sh
```

### On Linux
```bash
sudo apt install nasm gcc binutils grub-pc-bin grub-common xorriso qemu-system-x86
mkdir build
./build.sh
```

### Running
```bash
# In QEMU (Termux or Linux)
qemu-system-x86_64 -m 128M -cdrom cinoz.iso

# With display (Termux + VNC or SDL)
qemu-system-x86_64 -m 128M -cdrom cinoz.iso -display sdl
```

## File Structure
```
cinoz/
├── boot/
│   ├── multiboot.asm   — Multiboot2 header (GRUB recognition)
│   └── entry.asm       — Boot entry, long mode setup, paging
├── kernel/
│   ├── main.c          — kernel_main(), shell, UI
│   └── linker.ld       — Linker script
├── drivers/
│   ├── fb.c            — Framebuffer + font + printf
│   └── keyboard.c      — PS/2 keyboard polling driver
├── include/
│   ├── fb.h
│   ├── keyboard.h
│   ├── multiboot2.h
│   └── types.h
├── tools/
│   └── grub.cfg        — GRUB boot menu config
├── build.sh            — Build script
├── setup.sh            — First-time setup
└── README.md
```

## License
MIT — do whatever you want with it.

; Cinoz - Multiboot2 header
; Tells GRUB to load us and set up a framebuffer

BITS 32
section .multiboot2
align 8
header_start:
    dd 0xE85250D6                  ; magic
    dd 0                           ; arch: i386 protected mode
    dd header_end - header_start   ; header length
    dd 0x100000000 - (0xE85250D6 + 0 + (header_end - header_start)) ; checksum

    ; Framebuffer tag - request 1024x768x32
    align 8
    framebuffer_tag_start:
    dw 5                           ; type: framebuffer
    dw 1                           ; flags
    dd framebuffer_tag_end - framebuffer_tag_start
    dd 1024                        ; width
    dd 768                         ; height
    dd 32                          ; depth
    framebuffer_tag_end:

    ; End tag
    align 8
    dw 0                           ; type: end
    dw 0
    dd 8
header_end:

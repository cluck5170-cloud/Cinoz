; Cinoz - Boot entry point
; GRUB loads us in 32-bit protected mode. We set up paging and jump to 64-bit.

BITS 32
KERNEL_VIRT_BASE equ 0xFFFFFFFF80000000  ; higher half kernel
KERNEL_PHYS_BASE equ 0x100000

section .bss
align 4096
pml4:    resb 4096
pdpt:    resb 4096
pd:      resb 4096
pt:      resb 4096
stack_bottom:
    resb 32768          ; 32 KB stack
stack_top:

section .data
align 4096
gdt64:
    dq 0                        ; null descriptor
.code: equ $ - gdt64
    dq (1<<44)|(1<<47)|(1<<41)|(1<<43)|(1<<53) ; 64-bit code
.data: equ $ - gdt64
    dq (1<<44)|(1<<47)|(1<<41)              ; 64-bit data
.pointer:
    dw $ - gdt64 - 1
    dq gdt64

section .text
global _start
extern kernel_main

_start:
    ; Save multiboot info pointer (ebx = info, eax = magic)
    mov edi, eax        ; magic
    mov esi, ebx        ; multiboot info pointer

    ; Set up stack
    mov esp, stack_top

    ; Check if CPUID is available
    pushfd
    pop eax
    mov ecx, eax
    xor eax, 1 << 21
    push eax
    popfd
    pushfd
    pop eax
    push ecx
    popfd
    cmp eax, ecx
    je .no_cpuid

    ; Check for long mode
    mov eax, 0x80000000
    cpuid
    cmp eax, 0x80000001
    jb .no_long_mode

    mov eax, 0x80000001
    cpuid
    test edx, 1 << 29
    jz .no_long_mode

    ; Set up page tables (identity map first 2MB + higher half)
    ; PML4[0] -> PDPT (identity)
    mov eax, pdpt
    or eax, 0x3
    mov [pml4], eax
    ; PML4[511] -> PDPT (higher half)
    mov [pml4 + 511*8], eax

    ; PDPT[0] -> PD
    mov eax, pd
    or eax, 0x3
    mov [pdpt], eax
    ; PDPT[510] -> PD (for higher half 0xFFFFFFFF80000000)
    mov [pdpt + 510*8], eax

    ; PD[0] -> 2MB huge page at 0x0 (flags: huge, present, writable)
    mov dword [pd], 0x83

    ; Load PML4
    mov eax, pml4
    mov cr3, eax

    ; Enable PAE
    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    ; Set LME bit in EFER
    mov ecx, 0xC0000080
    rdmsr
    or eax, 1 << 8
    wrmsr

    ; Enable paging + protected mode
    mov eax, cr0
    or eax, (1 << 31) | (1 << 0)
    mov cr0, eax

    ; Load 64-bit GDT and far jump
    lgdt [gdt64.pointer]
    jmp gdt64.code:long_mode_entry

BITS 64
long_mode_entry:
    mov ax, gdt64.data
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ; Reload stack in higher half
    mov rax, KERNEL_VIRT_BASE
    ; (stack is in .bss which is linked at physical, but we'll pass 0 for now)

    ; Call kernel main(magic, multiboot_info_ptr)
    ; edi already has magic, esi has info ptr — zero-extend to 64-bit
    movzx rdi, edi
    movzx rsi, esi
    call kernel_main
    jmp halt

halt:
    hlt
    jmp halt

.no_cpuid:
.no_long_mode:
    ; Write "ERR" to VGA and halt
    mov dword [0xB8000], 0x4F524F45  ; ER
    mov dword [0xB8004], 0x4F524F52  ; RR
    hlt

#!/bin/bash
# Cinoz build script
# Requirements: nasm, gcc (cross or native x86_64-elf), grub-mkrescue, xorriso
# Install in Termux: pkg install nasm gcc grub xorriso

set -e
cd "$(dirname "$0")"

echo "[cinoz] Assembling boot/multiboot.asm ..."
nasm -f elf64 boot/multiboot.asm -o build/multiboot.o

echo "[cinoz] Assembling boot/entry.asm ..."
nasm -f elf64 boot/entry.asm -o build/entry.o

echo "[cinoz] Compiling kernel/main.c ..."
gcc -ffreestanding -fno-stack-protector -fno-pie -fno-pic \
    -nostdlib -nostdinc \
    -mno-red-zone -mcmodel=kernel \
    -std=c11 -O2 -Wall -Wextra \
    -c kernel/main.c -o build/main.o

echo "[cinoz] Compiling drivers/fb.c ..."
gcc -ffreestanding -fno-stack-protector -fno-pie -fno-pic \
    -nostdlib -nostdinc \
    -mno-red-zone -mcmodel=kernel \
    -std=c11 -O2 \
    -c drivers/fb.c -o build/fb.o

echo "[cinoz] Compiling drivers/keyboard.c ..."
gcc -ffreestanding -fno-stack-protector -fno-pie -fno-pic \
    -nostdlib -nostdinc \
    -mno-red-zone -mcmodel=kernel \
    -std=c11 -O2 \
    -c drivers/keyboard.c -o build/keyboard.o

echo "[cinoz] Linking ..."
ld -T kernel/linker.ld -nostdlib \
   build/multiboot.o build/entry.o \
   build/main.o build/fb.o build/keyboard.o \
   -o build/cinoz.elf

echo "[cinoz] Building ISO ..."
mkdir -p isoroot/boot/grub
cp build/cinoz.elf isoroot/boot/cinoz.elf
cp tools/grub.cfg  isoroot/boot/grub/grub.cfg

grub-mkrescue -o cinoz.iso isoroot 2>/dev/null

echo ""
echo "  ✓ cinoz.iso built successfully!"
echo "  Run with: qemu-system-x86_64 -m 128M -cdrom cinoz.iso"
echo "  Or Termux: qemu-system-x86_64 -m 128M -cdrom cinoz.iso -display sdl"
